<?php

date_default_timezone_set('Asia/Jakarta');

$server   = "localhost";
$username = "id13081406_sekolah";
$password = "widi0101";
$database = "id13081406_db_sekolah";

$db = mysqli_connect($server,$username,$password,$database);

if(!$db){
    die('Koneksi Databse Gagal :'. mysqli_connect_error());
}

?>